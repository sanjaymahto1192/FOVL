# FOVL Word Embeddings — Indian Language Word Similarity

300-dimensional word embeddings trained **from scratch** on the IndicCorpV2-5k subset and
evaluated on the Akhtar et al. (2017) word-similarity benchmark for seven Indian languages:
Gujarati, Hindi, Marathi, Punjabi, Tamil, Telugu and Urdu.

No pre-trained embeddings. No external corpora. Human similarity scores are used only for
reporting, never for training or optimization.

**Submitted model: a four-member ensemble packed into exactly 300 dimensions.**
**Macro-average Spearman on the public benchmark: +0.3076.**

---

## How to run

```bash
python -m pip install "numpy>=2" "scipy>=1.14" "gensim>=4.4" scikit-learn pandas matplotlib pyarrow
jupyter notebook FOVL_Word_Embeddings.ipynb      # run all cells, top to bottom
```

Requires `data/indiccorpV2_project.parquet` and `data/word_similarity/*-WS.txt`.
**No network access is needed at any point.** Runtime is roughly 10–15 minutes on CPU
(`workers=1` is set deliberately, because gensim is non-deterministic above one worker).

Everything is inside the notebook — there are no `.py` imports, as the brief requires.

---

## Results

Macro-average Spearman **+0.3076**. The brief asks for cosine similarity, per-language
Spearman and the macro-average; those are the metrics reported, together with the vocabulary
coverage and OOV statistics it also requires.

| Language | n scored | Spearman | type coverage | pair-level OOV |
|---|---|---|---|---|
| Gujarati | 163 | +0.3968 | 89.6% | 14.1% |
| Hindi | 235 | +0.3113 | 87.7% | 24.3% |
| Marathi | 104 | +0.4188 | 80.7% | 25.0% |
| Punjabi | 143 | +0.3140 | 89.3% | 17.5% |
| Tamil | 97 | +0.2527 | 83.1% | 26.8% |
| Telugu | 111 | +0.2071 | 73.1% | 42.3% |
| Urdu | 100 | +0.2522 | 82.9% | 24.0% |
| **macro** | 958 | **+0.3076** | | |

### What was actually tested

| # | configuration | macro |
|---|---|---|
| **I** | **mono FastText + count ensemble (submitted)** | **+0.3076** |
| B | mono FastText-SG 300d | +0.2989 |
| C | joint script-unified FastText-SG 300d | +0.2860 |
| D | joint script-unified PPMI-SVD 300d | +0.2530 |
| G | mono 4-member count-only ensemble | +0.2438 |
| F | joint count ensemble + all-but-the-top | +0.2200 |
| A | mono PPMI-SVD 300d | +0.2112 |
| — | character n-grams, **no training at all** | +0.1437 |

**Read these differences against the noise floor.** Simulated at these exact sample sizes, the
per-language Spearman SD is ≈0.07 and the macro-average SD ≈0.034, so a 95% interval on macro
spans roughly **±0.06**. (Confidence intervals are not reported in `results.csv`, which carries
only the metrics the brief asks for; the figure is quoted here to frame the comparisons.) The submitted ensemble beats plain FastText by **+0.009** — that is a
**statistical tie, not a win**, and the README states it as such.

The ensemble is submitted anyway, on grounds that do not depend on the public score:

* The public benchmark is WS-353 **set1**; the private set is almost certainly **set2** (see
  below). Selection happens under distribution shift, and ensembles transfer better than an
  argmax-selected single model.
* It contains a member that is **never undefined**, which caps downside when private OOV is
  higher than the 14–42% measured here.
* It reduces run-to-run variance, which is large at this corpus size.

Per-language the two models are complementary rather than ranked — FastText and the
count-based members have a profile correlation of only **r = +0.11**. FastText is better on
Gujarati (+0.434 vs +0.377) and Urdu (+0.353 vs +0.293); the ensemble is much better on
Marathi (+0.316 vs +0.159) and Hindi (+0.396 vs +0.311). Oracle per-language selection would
reach +0.324, which is the headroom a better combiner could recover.

---

## Method

### Architecture — 300 dimensions as an ensemble budget

| member | dim | weight | inductive bias |
|---|---|---|---|
| FastText skip-gram, window 12, char n-grams 4–10 | 150 | 0.50 | prediction + subword OOV |
| PPMI-SVD, window 10, harmonic, CDS α=0.75, w+c | 70 | 0.25 | count-based, topical |
| PPMI-SVD, window 2 | 40 | 0.10 | count-based, functional |
| Character n-gram TF-IDF → SVD | 40 | 0.15 | orthographic; never undefined |

Each member is L2-normalized and scaled by `sqrt(wᵢ)` before concatenation. Then the result
has unit norm and

```
cos(x, y) == Σᵢ wᵢ · cos(uᵢ, vᵢ)      (exact, verified to float precision)
```

so concatenation *is* score-level ensembling while still producing one honest 300-d vector.
At ~200k tokens per language, a single 300-d model is heavily overparameterized; splitting
the budget across members with different inductive biases costs nothing and reduces variance.

The count-based members use the Levy–Goldberg–Dagan (2015) configuration: harmonic window
weighting, context distribution smoothing, eigenvalue weighting `Σ^p`, and adding context
vectors (`w+c`).

### OOV handling

Mandatory per the brief, and consequential here: measured pair-level OOV runs from **14%
(Gujarati) to 42% (Telugu)**. The cascade is

**exact → FastText subword → prefix expansion → character n-gram → deterministic hash**

and `embed_word()` is total: any string in, a finite unit-norm 300-d vector out. It never
raises, never returns zeros, and never returns NaN.

*Prefix expansion* exists because several Tamil/Telugu benchmark entries are **bare stems
that never occur standalone** — Tamil `காகித` (the free word is `காகிதம்`), Telugu `పుస్తక`
(the word is `పుస్తకం`). These are OOV by construction rather than by rarity, so no subword
model recovers them well. Candidates sharing a ≥4-character prefix are weighted by
`len(LCP)² · log(1+freq)`, which acts as a lemmatizer for suffixally-agglutinative languages.

*The terminal fallback is a hash-seeded unit vector, never the global mean.* A global-mean
fallback gives every OOV–OOV pair cosine exactly 1.0, pinning a large block of the test set
at the top of the ranking. The hash fallback is deterministic across runs and machines
(blake2b, not Python's salted `hash()`), near-orthogonal for distinct strings, and returns
cosine exactly 1.0 for identical strings — which matters because several files contain
identical-word pairs scored 10.

Multi-word entries (Urdu 14, Marathi 4, Punjabi 2) are the L2-normalized mean of their
component tokens.

---

## Data handling — the part that mattered most

Four defects were found that are invisible at runtime and individually fatal. Fixing them
was worth more than every architecture choice combined.

### 1. Python's `\w` does not match Indic combining marks

Vowel signs such as `U+093E DEVANAGARI VOWEL SIGN AA` are Unicode category `Mc`/`Mn` —
neither alpha nor digit. So the obvious tokenizer shatters words:

```python
re.findall(r"\w+", "कंप्यूटर")   # -> ['क', 'प', 'य', 'टर']
```

This fails silently and destroys roughly **95% of benchmark coverage**. Word characters must
be `L*`, `M*` or `N*`.

### 2. NFC is mandatory and its absence is invisible

16 Tamil and 8 Telugu benchmark types are stored Unicode-**decomposed** (Tamil
`U+0BC6 + U+0BBE` instead of precomposed `ொ`; Telugu `U+0C46 + U+0C56` instead of `ై`). They
render identically to the precomposed forms, so without NFC they are 100% guaranteed OOV
with no error — including `టైగర్/టైగర్`, Telugu's identical-word pair scored 10.

Measured effect on Tamil type coverage: **73.5% → 83.1%**.

NFC is also the correct choice for nukta. Hindi/Punjabi benchmark words are already
decomposed (`base + U+093C`), while corpora emit precomposed `U+0958–095F`. Those are Unicode
composition exclusions, so NFC decomposes them too and **both sides converge**. NFD and
no-normalization are both wrong.

### 3. Six of seven files have no trailing newline

`wc -l` and `readlines()`-with-blank-filtering therefore **drop the last row** of six
languages, producing an invalid `.npy` shape.

| | Gujarati | Hindi | Marathi | Punjabi | Tamil | Telugu | Urdu | total |
|---|---|---|---|---|---|---|---|---|
| `wc -l` (wrong) | 162 | 235 | 252 | 142 | 96 | 110 | 99 | 1096 |
| **correct** | **163** | **235** | **253** | **143** | **97** | **111** | **100** | **1102** |

Files are read as bytes, decoded `utf-8-sig`, and split with `.splitlines()`; the expected
row count per language is hard-coded and asserted.

### 4. Urdu needs a hand-written fold that Unicode will not do

The benchmark uses exclusively Urdu letterforms (`U+06CC` farsi yeh ×107, `U+06A9` keheh ×49,
`U+06C1` heh goal ×27) and contains **zero** harakat and **zero** Arabic `U+064A`/`U+0643`.
The corpus contains all of them, and Unicode normalization does **not** map `U+064A → U+06CC`
— they are distinct letters. Folding the corpus toward the Urdu forms is strictly
coverage-increasing, since the benchmark contains none of the source forms.

### Other parsing hazards handled

* **Hindi is comma-delimited**; every other file is tab-delimited. Delimiters are declared
  per file, never sniffed — Tamil and Telugu contain commas *inside* tab-delimited fields.
* **Gujarati has four columns** and the fourth is not always empty (line 76 holds
  `0.867208`). The score is always `fields[2]`, never `fields[-1]`.
* **149 of 253 Marathi rows have no human score** (a contiguous tail, rows 105–253). They
  remain in the `.npy` in original order and are excluded only from Spearman.
* **Tamil line 81 has an empty second word**; lines 76/77 are comma-glued duplicates with
  conflicting scores (6.125 vs 6.0). Both rows are kept; the conflict is disclosed.
* **Marathi line 144** carries two leading `U+200B`; **line 145**'s second word is entirely
  Gujarati script inside the Marathi file.
* Boundary punctuation is stripped but **interior punctuation is preserved**, so `ਕੀ-ਬੋਰਡ`
  and `எப்.பி.` survive while glued commas (`ஜாகுவார்,`) are cleaned.

---

## What the benchmark actually is

The files are **WS-353 in translation**, and each public file is a *prefix* of the master
list. Gujarati rows 1–5 are love/sex, tiger/cat, tiger/tiger=10, book/paper,
computer/keyboard — verbatim WS-353 **set1** ordering.

The 149 unscored Marathi rows are **set2** with scores stripped: `लाभांश/पेमेंट`
(dividend/payment), `मीडिया/ट्रेडिंग` (media/trading), `शंभर/टक्के` (hundred/percent).

Three consequences, all reflected in the design:

1. **Public = set1, private ≈ set2**, so model selection happens under distribution shift and
   a public gain need not transfer. This is the main reason an ensemble was preferred over
   argmax selection.
2. **Set2 skews topical/relatedness** rather than taxonomic similarity, so windows are 10–15
   with harmonic weighting rather than gensim's default 5.
3. **Set2 is heavy in transliterated English and named entities**, so private OOV will exceed
   the 14–42% measured here. OOV handling is the leaderboard, not a checkbox.

---

## Negative results

Reported because they were measured, and because they contradict reasonable expectations.

* **Script unification was a wash.** Brahmic Unicode blocks are codepoint-offset aligned, and
  a ~15-line offset map raises benchmark type overlap from 0 to 79 (Gujarati↔Hindi) and 0 to
  47 (Hindi↔Punjabi). That overlap is real but did **not** convert into Spearman: joint−mono
  was −0.013 for FastText and +0.042 for PPMI-SVD, both inside noise. Per language it is two
  effects cancelling — Gujarati +0.040, Hindi +0.040, Marathi +0.084, but **Punjabi collapses
  −0.219**, because the Gurmukhi exception rules (addak→drop, tippi→anusvara) buy cross-script
  overlap by destroying genuine Punjabi distinctions.
* **All-but-the-top did not help.** −0.042 on monolingual, +0.020 on joint. Inconsistent sign,
  within noise. Not applied.
* **Count-based methods did not dominate.** The small-corpus literature (Sahlgren & Lenci;
  Altszyler et al.) predicts PPMI-SVD should beat SGNS below ~1M tokens. It did not here
  (+0.211 vs +0.299). At 170–360k tokens per language with 14–42% OOV, FastText's subword
  inference outweighs the count-based variance advantage. The count-based members still earn
  their place in the ensemble through decorrelation, not standalone accuracy.
* **No hyperparameter grid was run.** Eight configurations were evaluated in total. Selecting
  the argmax of K equally-good configurations inflates the public macro by ≈+0.03 (K=3) to
  ≈+0.09 (K=100) with no private-set gain, so searching harder would have produced a prettier
  public number and nothing else.

---

## A benchmark caveat worth noting

Hindi `मोहब्बत/सेक्स` is scored **6.8**; Punjabi `ਪਿਆਰ/ਸੈਕਸ` — the same concept pair — is
scored **1.0**. A 5.8-point disagreement between annotator pools means no model can satisfy
both. Rows like this are annotation variance, not model error.

Relatedly: **Spearman is rank-based and invariant to any monotone transform of cosine**, so a
raw cosine magnitude is never right or wrong on its own. Only the ordering within a language
is scored. The analysis table reports a `rank_gap` column for this reason.

---

## Outputs

Written to `outputs/` by the notebook:

| path | contents |
|---|---|
| `pair_embeddings/{lang}.npy` | `(N, 2, 300)` float32, original pair order, unscored rows included |
| `vocabularies/{lang}_mapping.json` | per row: raw words, normalized words, OOV layer, score |
| `vocabularies/{lang}_vocab.json` + `_vectors.npy` | token→index map and its vector matrix |
| `results.csv` | per-language Spearman and macro-average |
| `oov_statistics.csv` | coverage and OOV-layer breakdown per language |
| `corpus_profile.csv` | tokens, types, coverage per language |
| `analysis_examples.csv` | best- and worst-ranked pair per language |
| `tsne/{lang}.png` | 100-word t-SNE per language |
| `models/{lang}/` | saved FastText KeyedVectors + component arrays for offline reload (**excluded from the ZIP**, ~2.2 GB) |
| `FOVL_Experimental_Report.pdf` | the experimental report |
| `FOVL_Submission.zip` | notebook, README, report and artifacts |

A validator runs before packaging and asserts: exact `(N, 2, 300)` shape per language with
`N` matching the hard-coded row count, `float32`, no NaN/Inf, no zero-norm vectors, row order
round-tripped against an independent re-parse of the source file, mapping length matching the
array, identical-word pairs giving cosine 1.0, and no `.py`/`.pyc`/`__pycache__` in the ZIP.
Each check was tested by injecting the corresponding fault and confirming it is caught.

---

## Disclosure

* **Training data:** `data/indiccorpV2_project.parquet` only — 5,000 lines × 7 languages,
  1,664,509 tokens after normalization. The brief names IndicCorpV2 but links a 5,000-line
  subset; the linked subset was treated as the permitted corpus and nothing else was used.
* **Pre-trained models:** none.
* **External datasets:** none.
* **Tools:** gensim, numpy, scipy, scikit-learn, pandas, matplotlib, pyarrow. The script
  normalizer is a deterministic rule written for this project, not an external resource.
* **Human scores** were used only to report Spearman and to choose among 8 pre-registered
  configurations. No scores influenced any stored vector, any OOV decision, or any
  hyperparameter.

## Limitations

5,000 lines per language is a very small corpus, and the absolute Spearman values reflect
that — these are not production-quality embeddings. Per-language Spearman at n = 97-235 is unstable — a change that left the macro untouched
(+0.0003) moved individual languages by up to 0.10 — so per-language comparisons are weak
evidence. The private test set is
drawn from a different half of WS-353 than the public files, so the reported macro should be
read as an upper-biased estimate of private performance.

## References

* Doddapaneni et al. (2023). *Towards Leaving No Indic Language Behind* (IndicCorp v2). ACL.
* Akhtar et al. (2017). *Word Similarity Datasets for Indian Languages*.
* Finkelstein et al. (2002). *Placing Search in Context: The Concept Revisited* (WordSim-353).
* Levy, Goldberg & Dagan (2015). *Improving Distributional Similarity with Lessons Learned
  from Word Embeddings*. TACL.
* Bojanowski et al. (2017). *Enriching Word Vectors with Subword Information*. TACL.
* Mu & Viswanath (2018). *All-but-the-Top: Simple and Effective Post-processing for Word
  Representations*. ICLR.
